using System;

class Module039
{
  static bool object3 = true; // module-wide object

  static void operation1 (char object3)
  {
    Console.WriteLine (object3);
  }

  public static void Main (string[] args)
  {
    operation1 ('v');
  }
}