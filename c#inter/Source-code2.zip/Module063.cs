class Module063
{
  short column1; 
  char column1;

  public static void Main (string[] args)
  {
  }
}