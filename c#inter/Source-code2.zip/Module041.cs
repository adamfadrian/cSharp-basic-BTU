using System;

class Module041
{
  static bool object3 = true; // module-wide object

  static void operation1 ()
  {
    char object3 = 'v';
    Console.WriteLine (object3);
  }

  public static void Main (string[] args)
  {
    operation1 ();
  }
}