interface abc
{
  void xyz();
}