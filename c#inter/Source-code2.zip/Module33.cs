using System;

class Module33
{ // see Collection06

  static int[] Object1 = new int[] {9, 8, 7, 6, 5};

  public static void Main (string[] args)
  {
    Console.WriteLine (Object1[0]);
    Console.WriteLine (Object1.Length);
  } // in C# Basic book
}   // sec 10.3