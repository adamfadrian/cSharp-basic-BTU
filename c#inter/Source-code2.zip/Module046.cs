using System;

class Module046
{ // similar to Module02 in C# Basic sec 9.3
  static void operation1 ()
  {
    char object3 = 'v';
    Console.WriteLine (object3);
  }

  public static void Main (string[] args)
  {
    operation1 ();
  }
} // this time without error like in C# Basic sec 9.3