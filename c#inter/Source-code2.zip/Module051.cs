using System;

class Module051
{
  bool object3;        // record-scope object
  static char object3; // module-scope object
    
  static void operation1 (char object3)
  {
    Console.WriteLine (object3);
  }

  public static void Main (string[] args)
  {
    Module050 Object4 = new Module050();
    object3 = 'v';   
    object3 = false;
  }
}