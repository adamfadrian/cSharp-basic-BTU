using Namespace1;

class Module052
{
  public static void Main (string[] args)
  {
    Module001.operation1();
  }
}