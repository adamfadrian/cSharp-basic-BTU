interface InterfaceModule01
{
}