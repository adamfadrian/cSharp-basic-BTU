using System;

public class Module27
{
  public Module27 (bool operand1, char operand2)
  {
    object1 = operand1;
    object2 = operand2;
  }

  public static void Main (string[] args)
  {
    Module27 RecordObject1 = new Module27 (false, 'a');
    RecordObject1.operation2();
  }

  public void operation2()
  {
    Console.WriteLine (object1);
    Console.WriteLine (object2);
  }

  public bool object1 = true;
  public char object2 = 'a';
}