using System;

class Module075
{
  static void Main (string[] Lined_operands)
  {
    for (int counter = 0; counter < Lined_operands.Length; counter++)
      Console.WriteLine(Lined_operands[counter]);
  }
}