class Module031
{
  static void operation1 (bool b)
  {
    bool b;
  }

  public static void Main (string[] args) 
  { }
}