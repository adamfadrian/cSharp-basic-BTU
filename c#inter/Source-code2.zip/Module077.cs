using System;

public class Module077
{
  static void Main()
  {
    Console.WriteLine 
     (InterfaceModule2a.object4);
  }
}