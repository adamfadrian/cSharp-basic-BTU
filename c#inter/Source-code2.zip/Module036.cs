class Module036
{
  static void operation1 (bool b, char b)
  {
  }

  public static void Main (string[] args) 
  { }
}