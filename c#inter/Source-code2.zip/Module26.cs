using System;

public class Module26
{
  public static bool object1 = true;

  public static void Main (string[] args)
  {
    Console.WriteLine (object1);
    Console.WriteLine (object2);
  }

  public static char object2 = 'a';
}