using System;

class Module047
{ // similar to Module02 in C# Basic sec 9.3
  static bool object3 = false;

  public static void Main (string[] args)
  {
    Console.WriteLine (object3);
  }
} // this time without error like in C# Basic sec 9.3