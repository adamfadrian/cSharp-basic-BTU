class Module033
{
  static void operation1 ()
  {
    bool b, b;
  }

  public static void Main (string[] args) 
  { }
}