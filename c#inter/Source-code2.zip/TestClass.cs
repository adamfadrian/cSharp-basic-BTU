using generics = System.Collections.Generic;

namespace AliasExample
{ // copied from https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/namespaces/using-namespaces
  class TestClass
  {
    static void Main()
    {
      generics::Dictionary<string, int> dict = new generics::Dictionary<string, int>()
      {
        ["A"] = 1,
        ["B"] = 2,
        ["C"] = 3
      };

      foreach (string name in dict.Keys)
      { // expressions $"{name} {dict[name]}"
        System.Console.WriteLine(name, " ", dict[name]);
      } // are refused
      // Output:
      // A 1
      // B 2
      // C 3
    }
  }
}