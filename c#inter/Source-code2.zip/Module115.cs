class Module115
{
  public Module115 (short oprd1, char oprd2)
  {
    this.column1 = oprd1;
    this.column2 = oprd2;
  }

  short column1; char column2; // private columns

  public void set_column1 (short oprd1)
  { this.column1 = oprd1; }

  public void set_column2 (char oprd2)
  { this.column2 = oprd2; }
}