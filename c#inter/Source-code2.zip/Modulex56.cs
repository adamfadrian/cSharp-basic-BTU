using System;

class Module056
{
  bool object4 = true; // module-wide object

  static void operation1 () // involving operation-body only
  {
    Console.WriteLine (object3);  // access 'local' object
  }

  public static void Main (string[] args)
  {
    operation1 ();
  }
}