using System;
class Type20
{
  private static int object2 = 2;
  public static int[] object4 = new int[] {9, 8, 7, 6, 5};

  private static void operation2 ()
  { 
  //Console.WriteLine (object1);
    Console.WriteLine (Type20.object2); 
  //Console.WriteLine (object3);
    Console.WriteLine (Type20.object4);
  }

  public static void operation4 ()
  { 
  //Console.WriteLine (object1);
    Console.WriteLine (Type20.object2); 
  //Console.WriteLine (object3);
    Console.WriteLine (Type20.object4);
  }
}