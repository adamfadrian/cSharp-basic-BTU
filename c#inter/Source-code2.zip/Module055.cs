class Module055
{
  public static void Main (string[] args)
  {
    Console.WriteLine ("");
  }
}