class Module112
{
  public Module112 (short operand1, char operand2)
  {
    this.column1 = operand1;
    this.column2 = operand2;
  }

  short column1; char column2; // private columns

  public short get_column1 ()
  { return (column1); }

  public char get_column2 ()
  { return (column2); }
}