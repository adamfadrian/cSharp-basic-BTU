using System;
using System.IO;

class Output2File 
{
  static void Main (string[] args) 
  {
     FileStream OutputFile_Handle = new FileStream
      ("output_test1.data", FileMode.OpenOrCreate, FileAccess.ReadWrite);
    OutputFile_Handle.Position = 0;     
    OutputFile_Handle.WriteByte(65);
    OutputFile_Handle.Close();
  }
}