using System;

class Module037
{ 
  bool object3; 
  
  public static void Main (string[] args) 
  {
    Module037 Object4 = new Module037 ();
    Object4.object3 = true;
    char object3  = 'y';
    Console.WriteLine (object3); // which object3 ?
  }
}