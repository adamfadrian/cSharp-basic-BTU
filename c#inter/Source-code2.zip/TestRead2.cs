using System;

class TestRead2
{
  public void Numbers(string filename)
  {
    char[] Characters = new char[256];     

    string input;

    if (System.IO.File.Exists(filename) == true)
    {
      System.IO.StreamReader objectReader;
      objectReader = new System.IO.StreamReader(filename);
      while ((input = objectReader.Read()) != null)
      {
        Single output;
        if (Single.TryParse(input, out output ))
        {
            Characters.Add(output);
        }
        else
        {
           // Huh? Should this happen, maybe some logging can go here to track down why you couldn't just use the .Convert()
        }
      }
      objectReader.Close();
    }
    else
    {
        MessageBox.Show("No Such File" + filename);
    }
  }
  
  static void Main()
  {
  
  }
}