class Module145
{
  private static int object3 = 3;

  private static void operation3 ()
  {  }

  static void Main (string[] args)
  {
    Module145.operation3 ();
  }
}