using System;

public class Module29
{
  public Module29 (bool operand1, char operand2)
  {
    object1 = operand1;
    object2 = operand2;
  }

  public static void Main (string[] args)
  {
    Module29 RecordObject1 = new Module29 (false, 'a');
    RecordObject1.operation2();
  }

  public void operation2()
  {
    Console.WriteLine (object1);
    Console.WriteLine (object2);
  }

  private bool object1 = true;
  private char object2 = 'a';
}