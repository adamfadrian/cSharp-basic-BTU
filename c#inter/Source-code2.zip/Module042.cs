class Module042
{ // module-wide object
  public static bool object3 = true; 
}