class Empty
{
  public Empty()
  {
  }
}