using System;

class Module074
{
  public static void Main (string[] args)
  {
    Console.Write ("Input boolean value: "); 
    bool object1 = Convert.ToBoolean (Console.ReadLine ());
    Console.Write ("Input byte value: ");
    byte object2 = Convert.ToByte (Console.ReadLine ());
    Console.Write ("Input char value: ");
    char object3 = Convert.ToChar (Console.ReadLine ());
    Console.Write ("Input double-precision floating-point value: ");
    double object4 = Convert.ToDouble (Console.ReadLine ());
    Console.Write ("Input single-precision floating-point value: ");
    float object5 = Convert.ToSingle(Console.ReadLine ());
    Console.Write ("Input integer value: ");
    int object6 = Convert.ToInt32 (Console.ReadLine ());
    Console.Write ("Input long integer value: ");
    long object7 = Convert.ToInt64 (Console.ReadLine ());
    Console.Write ("Input short integer value: ");
    short object8 = Convert.ToInt16 (Console.ReadLine ());;
  }
}
