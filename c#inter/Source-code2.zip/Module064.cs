public class Module064
{
  class Module065
  {
    public Module065() { }
  }

  public Module064()
  {
    new Module065();
  }
}