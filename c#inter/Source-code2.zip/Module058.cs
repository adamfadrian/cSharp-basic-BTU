using System;

class Module058
{
  static void Main()
  {
    Module057 Object1 = new Module057 (6, 'b');
    Console.Write (Object1.get_column1());
    Console.WriteLine (Object1.get_column2());
    Object1.set_column1 (5);
    Object1.set_column2 ('e');
    Console.Write (Object1.get_column1());
    Console.WriteLine (Object1.get_column2());
  }
}