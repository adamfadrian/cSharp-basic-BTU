class Module143
{
  private int column2;

  Module143 (int operand2)
  {
    this.column2 = operand2;
  }

  int operation2 ()
  {
    return (this.column2);
  }

  static void Main (string[] args)
  {
    Module143 X = new Module143 (6);
    X.operation2 ();
  }
}