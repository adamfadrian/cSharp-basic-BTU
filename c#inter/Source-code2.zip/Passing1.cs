using System;

class Passing1
{
  public static void swap (object operand1, object operand2)
  {
    object temp = operand1;
    operand1 = operand2;
    operand2 = temp;
  }
  
  public static void Main (string[] args)
  {
    object object1 = 'a';
    object object2 = 'b';
    Console.WriteLine("Values before swapping: " + object1 + ", " + object2);
    swap (object1, object2);
    Console.WriteLine("Values after swapping: " + object1 + ", " + object2); 
  }
}