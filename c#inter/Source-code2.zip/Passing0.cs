using System;

class Passing0
{
  public static void swap (char operand1, char operand2)
  {
    char temp = operand1;
    operand1 = operand2;
    operand2 = temp;
  }
  
  public static void Main (string[] args)
  {
    char object1 = 'a';
    char object2 = 'b';
    Console.WriteLine ("Values before swapping: " + object1 + ", " + object2);
    swap (object1, object2);
    Console.WriteLine("Values after swapping: " + object1 + ", " + object2); 
  }
}