using System;

class Module029
{
  static void operation1 (bool b, char c)
  {
    Console.WriteLine (b);
    Console.WriteLine (c);
  }

  public static void Main (string[] args)
  {
    bool c = true;
    char b = 'z';
    operation1 (c, b);
  }
}