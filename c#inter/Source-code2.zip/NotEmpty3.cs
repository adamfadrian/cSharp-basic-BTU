using System;

public class NotEmpty3
{
  public static void operation2()
  {
    Console.WriteLine ("Hello");
  }

  public static void Main (string[] Operand1)
  {
    Console.WriteLine ("worlding");
  }
}