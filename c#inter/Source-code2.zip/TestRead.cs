using System; 
using System.IO; 
  
class TestRead 
{ 
  public static void Main() 
  { 
    try 
    {
      using (StreamReader sr = new StreamReader("TestFile.text")) 
      { 
        string line; 
        while ((line = sr.ReadLine()) != null) 
        { 
          Console.WriteLine(line); 
        } 
      } 
    }
    catch (Exception error1) 
    { // let the user know what went wrong. 
      Console.WriteLine ( "The fi1e cou1d not be read:"); 
      Console.WriteLine (error1.Message); 
    }  
  } 
}