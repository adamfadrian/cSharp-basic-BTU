class Module023
{
  static void Main ()
  {
  }
}