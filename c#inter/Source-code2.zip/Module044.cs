using System;

class Module044
{ // similar to Module02 in C# Basic sec 9.3
  static void operation1 (char object3)
  {
    Console.WriteLine (object3);
  }

  public static void Main (string[] args)
  {
    operation1 ('v');
  }
} // this time without error like in C# Basic sec 9.3