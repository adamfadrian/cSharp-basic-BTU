using System;

class Module073
{
  public static void Main (string[] args)
  {
    bool object1 = true;
    byte object2 = 1;
    char object3 = 'c';
    double object4 = 1.25;
    float object5 = -2.5f;
    int object6 = -123;
    long object7 = 123;
    short object8 = 12;
    Console.WriteLine (object1);
    Console.WriteLine (object2);
    Console.WriteLine (object3);
    Console.WriteLine (object4);
    Console.WriteLine (object5);
    Console.WriteLine (object6);
    Console.WriteLine (object7);
    Console.WriteLine (object8);
  }
}
