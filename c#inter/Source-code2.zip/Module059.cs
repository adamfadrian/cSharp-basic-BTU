class Module059
{
  short _column1; // private object/column

  public Module059 (short operand)
  {
    this._column1 = operand;
  }

  public short column1   // property ?
  {
    get { return (_column1) ; } // operation 
    set { _column1   = value; } // operation 
  }
}