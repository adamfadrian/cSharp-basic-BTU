using System;

public class Module076
{
  static void Main()
  {
    Console.WriteLine 
     (InterfaceModule02.object4);
  }
}