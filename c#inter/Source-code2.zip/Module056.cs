using System;

class Module056
{
  public static void Main (string[] args)
  {
    Console.WriteLine ("");
  }
}