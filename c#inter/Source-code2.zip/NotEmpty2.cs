public class NotEmpty2
{
  public static void Main ()
  {
  }
}