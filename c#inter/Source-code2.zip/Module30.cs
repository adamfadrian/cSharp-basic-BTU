using System;

public class Module30
{
  private static int object1 = object2 + 1;

  public static void Main (string[] args)
  {
    Console.WriteLine (object1);
    Console.WriteLine (object2);
  }

  private static int object2 = 2;
}