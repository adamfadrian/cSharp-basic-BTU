using System;

class Module109
{
  static void Main()
  {
    Module112 Object1 = new Module112 (6, 'B');
    short x = Object1.get_column1 ();
    Console.Write (x);
  }
}