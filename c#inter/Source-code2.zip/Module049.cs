using System;

class Module049
{
  bool object3; // module-wide object

  static void operation1 (char object3)
  {
    Console.WriteLine (object3);
  }

  public static void Main (string[] args)
  {
    operation1 ('v');
  }
}