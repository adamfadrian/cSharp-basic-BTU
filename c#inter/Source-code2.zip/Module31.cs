using System;

public class Module31
{
  public Module31 ()
  {
  }

  public static void Main (string[] args)
  {
    Module31 RecordObject1 = new Module31 ();
    RecordObject1.operation2();
  }

  public void operation2()
  {
    Console.WriteLine (object1);
    Console.WriteLine (object2);
  }

  private int object1 = object2 + 1;
  private int object2 = 2;
}