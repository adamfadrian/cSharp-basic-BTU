using System;

class Module048
{ // similar to Module02 in C# Basic sec 9.3
  static char object3 = 'v';

  public static void Main (string[] args)
  {
    Console.WriteLine (object3);
  }
} // this time without error like in C# Basic sec 9.3