class Module035
{
  static void operation1 (bool b, bool b)
  {
  }

  public static void Main (string[] args) 
  { }
}