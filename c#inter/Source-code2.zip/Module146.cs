using System;

class Module146
{
  private static int object3 = 3;

  private static void operation3 ()
  {  
    Console.WriteLine (object3);
  }

  public static void operation4 ()
  {  
    operation3();
  }

  static void Main (string[] args)
  {
    Module146.operation4 ();
  }
}