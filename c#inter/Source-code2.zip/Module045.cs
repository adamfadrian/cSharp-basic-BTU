using System;

class Module045
{ // similar to Module02 in C# Basic sec 9.3
  static void operation1 ()
  {
    bool object3 = false;
    Console.WriteLine (object3);
  }

  public static void Main (string[] args)
  {
    operation1 ();
  }
} // this time without error like in C# Basic sec 9.3