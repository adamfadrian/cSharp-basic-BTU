using System;

public class Module24
{
  private static void operation2()
  {
    Console.WriteLine ("This is operation2.");
  }

  public static void Main (string[] args)
  {
    operation2();
    operation3();
  }

  private static void operation3()
  {
    Console.WriteLine ("This is operation3.");
  }
}