class Module066
{
  static void Main()
  {
    Module064 RecObject1 = new Module064();
  }
}