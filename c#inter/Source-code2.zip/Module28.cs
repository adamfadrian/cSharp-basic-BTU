using System;

public class Module28
{
  private static bool object1 = true;

  public static void Main (string[] args)
  {
    Console.WriteLine (object1);
    Console.WriteLine (object2);
  }

  private static char object2 = 'a';
}