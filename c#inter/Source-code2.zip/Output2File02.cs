using System;
using System.IO;

public class Output2File02 
{
  static void Main ()
  {
    try
    {
      StreamWriter StreamWriter1 = new StreamWriter ("output_test2.data");   
      StreamWriter1.WriteLine ("The quick brown fox jumps over the lazy dog.");    
      StreamWriter1.Close();
      Console.WriteLine("success..."); // output to screen
    }
    catch (Exception error1)
    { Console.WriteLine (error1); }
  }
}