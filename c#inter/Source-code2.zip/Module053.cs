class Module053
{
  public static void Main (string[] args)
  {
    WriteLine ("");
  }
}