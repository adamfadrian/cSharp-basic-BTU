using System;

class Module028
{
  static void operation1 (bool b, char c)
  {
    Console.WriteLine (b);
    Console.WriteLine (c);
  }

  public static void Main (string[] args)
  {
    operation1 (true, 'z');
  }
}