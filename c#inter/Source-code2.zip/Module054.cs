using System;

class Module054
{
  public static void Main (string[] args)
  {
    WriteLine ("");
  }
}