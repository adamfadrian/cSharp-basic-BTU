class Module025
{
  static void Main ()
  {
  }
}