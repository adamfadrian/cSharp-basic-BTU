using System;

class Module030
{
  static void operation1 (bool b, char c)
  {
    Console.WriteLine (b);
    Console.WriteLine (c);
  }

  public static void Main (string[] args)
  {
    bool x = true;
    char y = 'z';
    operation1 (x, y);
  }
}