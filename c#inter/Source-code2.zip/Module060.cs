using System;

class Module060
{
  static void Main()
  {
    Module059 Object1 = new Module059 (6);
    Console.WriteLine (Object1.column1);
    Object1.column1 = 5;
    Console.WriteLine (Object1.column1);
  }
}