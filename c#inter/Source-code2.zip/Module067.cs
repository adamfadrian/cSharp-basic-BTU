class Module067
{
  static void Main()
  {
    new Module065();
  }
}