class Module116
{
  static void Main()
  {
    Module115 Object1 = new Module115 (6, 'b');
    Object1.set_column1 (5);
    Object1.set_column2 ('e');
  }
}