using System;

public class Module25
{
  private void operation2()
  {
    Console.WriteLine ("This is operation2.");
  }

  public static void Main (string[] args)
  {
    Module25 RecordObject1 = new Module25();
    RecordObject1.operation2();
    RecordObject1.operation3();
  }

  private void operation3()
  {
    Console.WriteLine ("This is operation3.");
  }
}