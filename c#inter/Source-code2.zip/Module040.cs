using System;

class Module040
{
  static bool object3 = true; // module-wide object

  static void operation1 ()
  {
    bool object3 = false;
    Console.WriteLine (object3);
  }

  public static void Main (string[] args)
  {
    operation1 ();
  }
}